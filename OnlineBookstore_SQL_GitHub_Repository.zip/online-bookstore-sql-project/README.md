# Online Bookstore SQL Project

A PostgreSQL portfolio project that models a small online bookstore and answers business questions about books, customers, orders, sales, and inventory.

## Project overview

This project demonstrates how SQL can be used to:
- Design a relational database with primary and foreign keys.
- Filter and sort records using `WHERE` and `ORDER BY`.
- Summarize data with aggregate functions such as `SUM`, `AVG`, and `COUNT`.
- Analyze customer and book activity using `JOIN`, `GROUP BY`, and `HAVING`.
- Examine sales, customer spending, popular books, and inventory.

**Database:** PostgreSQL  
**Language:** SQL  
**Project type:** Beginner-to-intermediate data analysis / database project

## Repository structure

```text
online-bookstore-sql-project/
├── sql/
│   ├── 01_create_database.sql
│   ├── 02_create_tables.sql
│   ├── 03_basic_analysis.sql
│   └── 04_advanced_analysis.sql
├── docs/
│   └── database_relationships.md
├── original/
│   └── OnlineBookstore_SQL_Corrected.sql
├── .gitignore
└── README.md
```

## Database design

The database contains three tables:

| Table | Purpose | Primary key |
|---|---|---|
| `Books` | Book details, genre, price, publication year, and stock | `Book_ID` |
| `Customers` | Customer contact and location information | `Customer_ID` |
| `Orders` | Orders, quantities, dates, and total amounts | `Order_ID` |

### Entity relationship diagram

```mermaid
erDiagram
    CUSTOMERS ||--o{ ORDERS : places
    BOOKS ||--o{ ORDERS : appears_in

    CUSTOMERS {
        int Customer_ID PK
        varchar Name
        varchar Email
        varchar Phone
        varchar City
        varchar Country
    }

    BOOKS {
        int Book_ID PK
        varchar Title
        varchar Author
        varchar Genre
        int Published_Year
        numeric Price
        int Stock
    }

    ORDERS {
        int Order_ID PK
        int Customer_ID FK
        int Book_ID FK
        date Order_Date
        int Quantity
        numeric Total_Amount
    }
```

## How to run the project

1. Install PostgreSQL and open a PostgreSQL client such as pgAdmin or `psql`.
2. Run `sql/01_create_database.sql` while connected to the default maintenance database (for example, `postgres`).
3. Connect to the newly created `OnlineBookstore` database.
4. Run `sql/02_create_tables.sql`.
5. Load your own sample or project dataset into the three tables.
6. Run `sql/03_basic_analysis.sql` and `sql/04_advanced_analysis.sql`.

> **Important:** The uploaded project contains table definitions and analysis queries, but no data-insertion statements or dataset. The analysis queries will return no meaningful results until records are loaded into the tables.

## Analysis questions covered

### Basic analysis
- Books in the Fiction genre.
- Books published after 1950.
- Customers from Canada.
- Orders placed during November 2023.
- Total book stock.
- Most expensive book.
- Customers with an order quantity greater than one.
- Orders with a total amount above $20.
- Distinct book genres.
- Book with the lowest recorded stock.
- Total revenue from orders.

### Advanced analysis
- Total books sold by genre.
- Average price of Fantasy books.
- Customers with at least two orders.
- Most frequently ordered book.
- Three most expensive Fantasy books.
- Total quantity sold by author.
- Customers and cities with cumulative spending above $30.
- Customer with the highest total spending.
- Remaining-stock calculation based on recorded stock and ordered quantities.

## Notes and assumptions

- The schema uses PostgreSQL syntax (`SERIAL`, `NUMERIC`, and `CREATE DATABASE`).
- `Orders.Total_Amount` is treated as the recorded order total; the project does not currently calculate it from book price and quantity.
- The remaining-stock query assumes `Books.Stock` represents stock **before** the orders being counted. If `Stock` already represents current stock, subtracting ordered quantities again would understate inventory.
- The SQL files are organized for readability. A few query outputs were aligned with their question wording (for example, returning one lowest-stock book and one highest-spending customer).

## Skills demonstrated

`PostgreSQL` · `Database Design` · `SQL Joins` · `Aggregations` · `Filtering` · `Grouping` · `Business Analysis` · `Inventory Analysis`

## Future improvements

- Add a reproducible sample dataset and data-loading script.
- Add constraints for positive prices and quantities, valid stock, and unique customer emails.
- Add indexes for frequently joined or filtered columns.
- Add views for monthly revenue and customer lifetime value.
- Add screenshots of query results and a short project walkthrough.

---

Created as a SQL learning and portfolio project.
