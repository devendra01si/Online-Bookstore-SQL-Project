-- Online Bookstore: advanced analysis queries
-- Run after loading records into Books, Customers, and Orders.

-- 1. Total quantity of books sold for each genre.
SELECT
    b.Genre,
    SUM(o.Quantity) AS Total_Books_Sold
FROM Orders AS o
JOIN Books AS b
    ON b.Book_ID = o.Book_ID
GROUP BY b.Genre
ORDER BY Total_Books_Sold DESC;

-- 2. Average price of books in the Fantasy genre.
SELECT AVG(Price) AS Average_Price
FROM Books
WHERE Genre = 'Fantasy';

-- 3. Customers who have placed at least two orders.
SELECT
    c.Customer_ID,
    c.Name,
    COUNT(o.Order_ID) AS Order_Count
FROM Customers AS c
JOIN Orders AS o
    ON o.Customer_ID = c.Customer_ID
GROUP BY c.Customer_ID, c.Name
HAVING COUNT(o.Order_ID) >= 2
ORDER BY Order_Count DESC;

-- 4. Find the most frequently ordered book (by number of order records).
SELECT
    b.Book_ID,
    b.Title,
    COUNT(o.Order_ID) AS Order_Count
FROM Orders AS o
JOIN Books AS b
    ON b.Book_ID = o.Book_ID
GROUP BY b.Book_ID, b.Title
ORDER BY Order_Count DESC
LIMIT 1;

-- 5. Top three most expensive books in the Fantasy genre.
SELECT *
FROM Books
WHERE Genre = 'Fantasy'
ORDER BY Price DESC
LIMIT 3;

-- 6. Total quantity of books sold by each author.
SELECT
    b.Author,
    SUM(o.Quantity) AS Total_Books_Sold
FROM Orders AS o
JOIN Books AS b
    ON b.Book_ID = o.Book_ID
GROUP BY b.Author
ORDER BY Total_Books_Sold DESC;

-- 7. Customers whose cumulative order spending exceeds $30,
-- including the city where each customer is located.
SELECT
    c.City,
    c.Customer_ID,
    c.Name,
    SUM(o.Total_Amount) AS Total_Spent
FROM Customers AS c
JOIN Orders AS o
    ON o.Customer_ID = c.Customer_ID
GROUP BY c.City, c.Customer_ID, c.Name
HAVING SUM(o.Total_Amount) > 30
ORDER BY Total_Spent DESC;

-- 8. Find the customer with the highest total spending.
SELECT
    c.Customer_ID,
    c.Name,
    SUM(o.Total_Amount) AS Customer_Spent
FROM Customers AS c
JOIN Orders AS o
    ON o.Customer_ID = c.Customer_ID
GROUP BY c.Customer_ID, c.Name
ORDER BY Customer_Spent DESC
LIMIT 1;

-- 9. Calculate remaining stock assuming Books.Stock is the
-- starting stock before the orders represented in Orders.
SELECT
    b.Book_ID,
    b.Title,
    b.Stock AS Starting_Stock,
    COALESCE(SUM(o.Quantity), 0) AS Ordered_Quantity,
    b.Stock - COALESCE(SUM(o.Quantity), 0) AS Remaining_Quantity
FROM Books AS b
LEFT JOIN Orders AS o
    ON o.Book_ID = b.Book_ID
GROUP BY b.Book_ID, b.Title, b.Stock
ORDER BY b.Book_ID;
