-- Online Bookstore: basic analysis queries
-- Run after loading records into Books, Customers, and Orders.

-- 1. Retrieve all books in the Fiction genre.
SELECT *
FROM Books
WHERE Genre = 'Fiction';

-- 2. Find books published after 1950.
SELECT *
FROM Books
WHERE Published_Year > 1950;

-- 3. List customers from Canada.
SELECT *
FROM Customers
WHERE Country = 'Canada';

-- 4. Show orders placed in November 2023.
SELECT *
FROM Orders
WHERE Order_Date >= DATE '2023-11-01'
  AND Order_Date < DATE '2023-12-01';

-- 5. Retrieve the total stock of books.
SELECT SUM(Stock) AS Total_Stock
FROM Books;

-- 6. Find the most expensive book.
SELECT *
FROM Books
ORDER BY Price DESC
LIMIT 1;

-- 7. Show customers who ordered more than one copy in an order.
SELECT DISTINCT
    c.Customer_ID,
    c.Name,
    c.Email
FROM Customers AS c
JOIN Orders AS o
    ON o.Customer_ID = c.Customer_ID
WHERE o.Quantity > 1;

-- 8. Retrieve orders where the total amount exceeds $20.
SELECT *
FROM Orders
WHERE Total_Amount > 20;

-- 9. List all distinct genres in the Books table.
SELECT DISTINCT Genre
FROM Books
ORDER BY Genre;

-- 10. Find the book with the lowest recorded stock.
SELECT *
FROM Books
ORDER BY Stock ASC
LIMIT 1;

-- 11. Calculate total revenue recorded across all orders.
SELECT SUM(Total_Amount) AS Total_Revenue
FROM Orders;
