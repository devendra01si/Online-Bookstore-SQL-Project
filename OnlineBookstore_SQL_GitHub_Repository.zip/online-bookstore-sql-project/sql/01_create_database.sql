-- Create the project database.
-- Run this file while connected to a maintenance database such as postgres.
CREATE DATABASE OnlineBookstore;
