# Database relationships

The OnlineBookstore database has three entities:

- **Books** (`Book_ID` primary key)
- **Customers** (`Customer_ID` primary key)
- **Orders** (`Order_ID` primary key)

Each order references one customer and one book. A customer can have multiple orders, and a book can appear in multiple orders.

```mermaid
erDiagram
    CUSTOMERS ||--o{ ORDERS : places
    BOOKS ||--o{ ORDERS : appears_in
```
